from django import forms
from .models import User
from django.core import validators


class PhonebookRegistration(forms.ModelForm):
    class Meta:
        model=User
        fields=['name','email','mobile']
        widgets={
        'name':forms.TextInput(attrs={'class':'form-control'}),
        'email':forms.EmailInput(attrs={'class':'form-control'}),
        'mobile':forms.NumberInput(attrs={'class':'form-control'}),
        }
