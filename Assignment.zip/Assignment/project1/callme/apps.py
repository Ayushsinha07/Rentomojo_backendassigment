from django.apps import AppConfig


class CallmeConfig(AppConfig):
    name = 'callme'
