from django.shortcuts import render,HttpResponseRedirect
from .forms import PhonebookRegistration
from .models import User
# Create your views here.
#this function will add contacts
def add_show(request):
    if request.method=='POST':
        fm=PhonebookRegistration(request.POST)
        if fm.is_valid():
            nm=fm.cleaned_data['name']
            em=fm.cleaned_data['email']
            pw=fm.cleaned_data['mobile']
            reg=User(name=nm,email=em,mobile=pw)
            reg.save()
            fm=PhonebookRegistration()
    else:
        fm=PhonebookRegistration()
    s= User.objects.all()
    return render(request,'callme/addandshow.html',{'form':fm,'stud':s})


#this function will delete contact

def delete_phone(request,id):
    if request.method=='POST':
        pi=User.objects.get(pk=id)
        pi.delete()
        return HttpResponseRedirect('/')

#this function will update

def update_phone(request,id):
    if request.method=='POST':
        pi=User.objects.get(pk=id)
        fm=PhonebookRegistration(request.POST,instance=pi)
        if fm.is_valid():
            fm.save()
    else:
        pi=User.objects.get(pk=id)
        fm=PhonebookRegistration(instance=pi)
    return render(request,'callme/update.html',{'form':fm})
